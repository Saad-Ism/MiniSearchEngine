from docx import Document
import nltk
nltk.data.path.append("/Users/saadismail/nltk_data")
import pickle


def load_docx(file_path):
    doc = Document(file_path)
    sentences = []
    tokenizer_path = "/Users/saadismail/nltk_data/tokenizers/punkt/english.pickle"
    with open(tokenizer_path, "rb") as f:
        tokenizer = pickle.load(f)

    for para in doc.paragraphs:
        text = para.text.strip()
        if text:
            sentences.extend(tokenizer.tokenize(text))

    return sentences