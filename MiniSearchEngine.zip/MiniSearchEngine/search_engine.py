import numpy as np
from preprocessing import TextPreProcessor
from vectorizer import TFIDFVectorizer


class SearchEngine:
    def __init__(self, documents):
        self.raw_documents = documents
        self.preprocessor = TextPreProcessor()
        self.vectorizer = TFIDFVectorizer()

        self.tokenized_docs = [self.preprocessor.preprocess(doc) for doc in documents]
        self.vectorizer.build_vocab(self.tokenized_docs)
        self.doc_vectors = self.vectorizer.vectorize_all(self.tokenized_docs)

    def cosine_similarity(self, vec1, vec2):
        if not np.any(vec1) or not np.any(vec2):
            return 0.0
        return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))

    def search(self, query, top_k=3):
        query_tokens = self.preprocessor.preprocess(query)
        query_vector = self.vectorizer.vectorize(query_tokens)

        similarities = [
            self.cosine_similarity(query_vector, doc_vec)
            for doc_vec in self.doc_vectors
        ]

        ranked_indices = np.argsort(similarities)[::-1][:top_k]

        return [(self.raw_documents[i], similarities[i]) for i in ranked_indices]