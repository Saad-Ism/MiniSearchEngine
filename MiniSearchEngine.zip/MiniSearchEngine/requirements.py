import nltk
nltk.data.path.append("/Users/saadismail/nltk_data")

from nltk.tokenize import sent_tokenize

text = "Mars is the fourth planet. It has two moons."
print(sent_tokenize(text))
