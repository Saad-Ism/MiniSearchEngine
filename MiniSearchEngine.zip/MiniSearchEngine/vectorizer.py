import numpy as np
from collections import defaultdict
import math


class BagOfWordsVectorizer:
    def __init__(self):
        self.vocab = {}
        self.inverse_vocab = {}

    def build_vocab(self, tokenized_documents):
        # Flatten and get all unique words
        all_tokens = set(token for doc in tokenized_documents for token in doc)
        self.vocab = {word: idx for idx, word in enumerate(sorted(all_tokens))}
        self.inverse_vocab = {idx: word for word, idx in self.vocab.items()}

    def vectorize(self, tokens):
        vector = np.zeros(len(self.vocab), dtype=int)
        for token in tokens:
            if token in self.vocab:
                vector[self.vocab[token]] += 1
        return vector

    def vectorize_all(self, tokenized_documents):
        return np.array([self.vectorize(doc) for doc in tokenized_documents])


class TFIDFVectorizer:
    def __init__(self):
        self.vocab = {}
        self.inverse_vocab = {}
        self.idf = {}

    def build_vocab(self, tokenized_documents):
        # Flatten and get all unique words
        all_tokens = set(token for doc in tokenized_documents for token in doc)
        self.vocab = {word: idx for idx, word in enumerate(sorted(all_tokens))}
        self.inverse_vocab = {idx: word for word, idx in self.vocab.items()}

        doc_count = defaultdict(int)
        for token in self.vocab:
            for doc in tokenized_documents:
                if token in doc:
                    doc_count[token] += 1

        total_docs = len(tokenized_documents)
        self.idf = {
            token: math.log(total_docs / (1 + doc_count[token]))
            for token in self.vocab
        }

    def vectorize(self, tokens):
        tf = defaultdict(int)
        for token in tokens:
            if token in self.vocab:
                tf[token] += 1

        total_terms = len(tokens)
        vector = np.zeros(len(self.vocab))

        for token, count in tf.items():
            tf_val = count / total_terms
            idf_val = self.idf.get(token, 0)
            vector[self.vocab[token]] = tf_val * idf_val

        return vector

    def vectorize_all(self, tokenized_documents):
        return np.array([self.vectorize(doc) for doc in tokenized_documents])