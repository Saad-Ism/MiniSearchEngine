import re
import nltk
nltk.data.path.append("/Users/saadismail/nltk_data")
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer


class TextPreProcessor:
    def __init__(self):
        self.stopwords = set(stopwords.words("english"))
        self.stemmer = PorterStemmer()

    def preprocess(self, text):
        # Lowercase
        text = text.lower()
        # Remove punctuation
        text = re.sub(r"[^\w\s]", "", text)
        # Tokenize
        raw_tokens = text.split()
        # Remove stopwords + apply stemming
        tokens = [
            self.stemmer.stem(word)
            for word in raw_tokens
            if word not in self.stopwords
        ]
        return tokens
