corpus = [
    "The movie was fantastic with stunning visuals and great performances.",
    "Absolutely terrible film. I regret watching it.",
    "An average movie with decent acting but a predictable plot.",
    "The story was gripping and the direction was brilliant.",
    "The film was a disaster. Poor script and worse execution.",
    "Great visuals but the story lacked depth.",
    "The cinematography was amazing, but the plot was weak.",
    "One of the best films I've seen this year.",
    "I fell asleep halfway through — boring and slow.",
    "Emotional and beautifully shot, a truly great experience."
]
