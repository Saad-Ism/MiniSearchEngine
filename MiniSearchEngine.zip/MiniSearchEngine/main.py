from corpus import corpus
from docx_reader import load_docx
from search_engine import SearchEngine

new_corpus = load_docx("input.docx")
engine = SearchEngine(new_corpus)
query = input("Enter a search query: ")
results = engine.search(query, top_k=3)

print("\nTop Results: ")
for i, (doc, score) in enumerate(results, 1):
    print(f"{i}. ({score:.2f}) {doc}")
